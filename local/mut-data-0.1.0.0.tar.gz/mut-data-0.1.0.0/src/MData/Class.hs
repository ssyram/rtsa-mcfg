{-# LANGUAGE FunctionalDependencies #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE UndecidableInstances #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE StandaloneDeriving #-}
{-# LANGUAGE InstanceSigs #-}
{-# OPTIONS_GHC -Wno-redundant-constraints #-}
module MData.Class (
  MData(..),
  IODataSt(IODataSt)
) where
import Control.Monad.ST.Strict ( RealWorld, stToIO, ST )


-- | The basic operations for Mutable Data Structure
class Monad m => MData d m | d -> m where
  new :: m (d e)
  len :: (Num n) => d e -> m n
  isEmpty :: d e -> m Bool
  isEmpty d = (== (0 :: Integer)) <$> len d

-- | The IO Data Structure accepting the corresponding ST Data Structure
newtype IODataSt stds e = IODataSt (stds RealWorld e)
deriving instance (Foldable (stds RealWorld)) => Foldable (IODataSt stds)

instance (MData (d RealWorld) (ST RealWorld)) => MData (IODataSt d) IO where
  new :: MData (d RealWorld) (ST RealWorld) => IO (IODataSt d e)
  new = stToIO $ fmap IODataSt new
  len :: (MData (d RealWorld) (ST RealWorld), Num n) => IODataSt d e -> IO n
  len (IODataSt d) = stToIO $ len d
  isEmpty :: MData (d RealWorld) (ST RealWorld) => IODataSt d e -> IO Bool
  isEmpty (IODataSt d) = stToIO $ isEmpty d
