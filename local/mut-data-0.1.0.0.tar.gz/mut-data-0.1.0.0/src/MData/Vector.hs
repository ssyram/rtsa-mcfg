{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE InstanceSigs #-}
{-# OPTIONS_GHC -Wno-name-shadowing #-}
{-# LANGUAGE TypeSynonymInstances #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE UndecidableInstances #-}
module MData.Vector (
  MData(..),
  MVector(..),
  STVector,
  IOVector,
  IODefVector
) where

import Control.Monad.ST ( RealWorld, stToIO, ST )
import Data.Array.ST
    ( STArray, readArray, writeArray, MArray(newArray) )
import Data.STRef
    ( modifySTRef, newSTRef, readSTRef, writeSTRef, STRef )
import Control.Monad ( when, forM_ )
import MData.Class (MData (..), IODataSt (IODataSt))
import Data.Functor (($>))

class MData v m => MVector v m where
  new_ :: Integer -> m (v e)
  newWithSize :: e -> Integer -> m (v e)
  readAt :: v e -> Integer -> m (Maybe e)
  -- | returns whether write succeeded
  --   may fail to write iff it is out of the bound of length
  writeAt :: v e -> Integer -> e -> m Bool
  -- | Given the `initPos` and `length` (NOT end position)
  --   returns whether ALL write succeeded
  --   may fail to write iff one of the index is out of the bound of length
  writeAll :: v e -> e -> Integer -> Integer -> m Bool
  insertAt :: v e -> Integer -> e -> m Bool
  -- | Enlarge the given `vec` by writing the `defaultVal` for the `additionalSize`.
  enlarge :: v e -> e -> Integer -> m ()
  pushBack :: v e -> e -> m ()

-- | The ST version of a mutable vector, capable of automatically managing size
data STVector s e = Vector {
  -- | Using `Nothing` as the placeholder for the value
  valVec :: !(STRef s (STArray s Integer (Maybe e))),
  lenVec :: !(STRef s Integer),
  capVec :: !(STRef s Integer)
}

-- autoResizeVecCap :: STVector s e -> ST s ()
-- autoResizeVecCap vec =
--   resizeVecCap vec . (+32) =<< readSTRef (capVec vec)

-- -- | resize the whole vector
-- resize :: Vector s e -> e -> Integer -> ST s ()
-- resize vec defaultVal newSize = do
--   oriLen <- readSTRef $ lenVec vec
--   oriCap <- readSTRef $ capVec vec
--   when (newSize > oriCap) $ resizeVecCap vec (newSize + 32)
--   writeSTRef (lenVec vec) newSize
--   when (newSize > oriLen) $ writeAll vec defaultVal

-- -- | automatically enlarge the vector
-- autoResize :: Vector s e -> ST s ()
-- autoResize vec = 
--   resize vec . (+32) =<< readSTRef (lenVec vec)

resizeVecCap :: STVector s e -> Integer -> ST s ()
resizeVecCap vec newCapacity = do
  l <- readSTRef $ lenVec vec
  oriArr <- readSTRef $ valVec vec
  newArr <- newArray (0, newCapacity - 1) Nothing  -- :: ST s (STArray s Integer (Maybe e))
  forM_ [0..min l newCapacity - 1] $ \idx ->
    writeArray newArr idx =<< readArray oriArr idx
  writeSTRef (valVec vec) newArr
  writeSTRef (capVec vec) newCapacity
  writeSTRef (lenVec vec) $ min l newCapacity


instance MData (STVector s) (ST s) where
  len :: (Num n) => STVector s e -> ST s n
  len vec = do
    int <- readSTRef $ lenVec vec
    return $ fromInteger int

  new :: ST s (STVector s e)
  new = new_ 32

instance MVector (STVector s) (ST s) where
  new_ :: Integer -> ST s (STVector s e)
  new_ capacity = do
    arr <- newArray (0, capacity - 1) Nothing  -- :: ST s (STArray s Integer (Maybe e))
    valVec <- newSTRef arr
    lenVec <- newSTRef 0 :: ST s (STRef s Integer)
    capVec <- newSTRef capacity :: ST s (STRef s Integer)
    return $ Vector valVec lenVec capVec

  pushBack :: STVector s e -> e -> ST s ()
  pushBack vec v = do
    l <- readSTRef $ lenVec vec
    c <- readSTRef $ capVec vec
    when (l + 1 >= c) $ resizeVecCap vec (c + 32)
    arr <- readSTRef $ valVec vec
    writeArray arr l $ Just v
    writeSTRef (lenVec vec) $ l + 1

  enlarge :: STVector s e -> e -> Integer -> ST s ()
  enlarge vec defaultVal additionalSize = do
    oriLen <- readSTRef $ lenVec vec
    oriCap <- readSTRef $ capVec vec
    let newSize = oriLen + additionalSize
    when (newSize > oriCap) $ resizeVecCap vec (newSize + 32)
    writeSTRef (lenVec vec) newSize
    writeAll vec defaultVal oriLen additionalSize $> ()

  readAt :: STVector s a -> Integer -> ST s (Maybe a)
  readAt vec idx = do
    !lenv <- readSTRef $ lenVec vec
    if lenv <= idx || idx < 0 then return Nothing
    else do
      arr <- readSTRef (valVec vec)
      ele <- readArray arr idx
      case ele of
        Nothing -> error $ "Read Undefined Value, at position " ++ show idx ++ "."
        Just e  -> return $ Just e

  writeAt :: STVector s e -> Integer -> e -> ST s Bool
  writeAt vec idx val = do
    !lenv <- readSTRef $ lenVec vec
    if lenv <= idx || idx < 0 then return False
    else do
      arr <- readSTRef (valVec vec)
      writeArray arr idx (Just val)
      return True

  -- | May insert at the back to create a new position
  insertAt :: STVector s e -> Integer -> e -> ST s Bool
  insertAt vec idx val = do
    !lenv <- readSTRef $ lenVec vec
    if lenv < idx || idx < 0 then return False
    else do
      c <- readSTRef (capVec vec)
      when (lenv + 1 >= c) $ resizeVecCap vec (c + 32)
      !arr <- readSTRef $ valVec vec
      forM_ [lenv, lenv - 1..idx + 1] $ \idx -> do
        writeArray arr (idx - 1) =<< readArray arr idx
      writeArray arr idx $ Just val
      modifySTRef (lenVec vec) (+1)
      return True

  newWithSize :: e -> Integer -> ST s (STVector s e)
  newWithSize initVal size
    | size < 0 = newWithSize initVal 0
    | otherwise = do
      arr <- new_ (size + 32)
      writeSTRef (lenVec arr) size
      writeAll arr initVal 0 size $> ()
      return arr

  writeAll :: STVector s t -> t -> Integer -> Integer -> ST s Bool
  writeAll vec initVal pos len
    | pos >= len = return True
    | otherwise  = do
      t <- writeAt vec pos initVal
      if t
        then writeAll vec initVal (pos + 1) len
        else return t

type IOVector = IODataSt

instance MVector (vst RealWorld) (ST RealWorld) =>
  MVector (IOVector vst) IO where
  new_ n = stToIO $ IODataSt <$> new_ n
  newWithSize e n = stToIO $ IODataSt <$> newWithSize e n
  readAt (IODataSt vst) n = stToIO $ readAt vst n
  writeAt (IODataSt vst) n e = stToIO $ writeAt vst n e
  writeAll (IODataSt vst) e n i = stToIO $ writeAll vst e n i
  insertAt (IODataSt vst) n e = stToIO $ insertAt vst n e
  enlarge (IODataSt vst) e n = stToIO $ enlarge vst e n
  pushBack (IODataSt vst) e = stToIO $ pushBack vst e

type IODefVector = IODataSt STVector
