{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE FunctionalDependencies #-}
{-# LANGUAGE UndecidableInstances #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE InstanceSigs #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE FlexibleInstances #-}
module MData.MQueue (MQueue(..), IOQueue) where
import Control.Monad (forM_)
import MData.Class (MData (..), IODataSt (..))
import Control.Monad.ST.Strict (RealWorld, stToIO, ST)

type IOQueue = IODataSt

instance MQueue (stq RealWorld) (ST RealWorld) => MQueue (IOQueue stq) IO where
  enqueue :: IOQueue stq e -> e -> IO ()
  enqueue (IODataSt stq) e = stToIO $ enqueue stq e
  dequeue :: IOQueue stq e -> IO (Maybe e)
  dequeue (IODataSt stq) = stToIO $ dequeue stq
  front :: IOQueue stq e -> IO (Maybe e)
  front (IODataSt stq) = stToIO $ front stq


-- | The class of Mutable Queue
class MData q m => MQueue q m | q -> m where
  -- | Default implementation: dequeue and then enqueue, return the value gotten out
  front :: q e -> m (Maybe e)
  front queue = do
    !hd <- dequeue queue
    forM_ hd $ enqueue queue
    return hd
  enqueue :: q e -> e -> m ()
  dequeue :: q e -> m (Maybe e)
