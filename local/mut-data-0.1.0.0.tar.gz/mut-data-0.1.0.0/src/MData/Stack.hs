{-# LANGUAGE FunctionalDependencies #-}
{-# LANGUAGE TypeSynonymInstances #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE UndecidableInstances #-}
{-# LANGUAGE InstanceSigs #-}
{-# OPTIONS_GHC -Wno-redundant-constraints #-}
{-# LANGUAGE LambdaCase #-}
module MData.Stack (
  STStack,
  IOStack,
  MStack(..),
  MData(..),
  IODefStack
) where

import Data.STRef
    ( modifySTRef, newSTRef, readSTRef, writeSTRef, STRef )
import Control.Monad.ST ( RealWorld, stToIO, ST )
import Data.Maybe ( listToMaybe )
import MData.Class ( MData, IODataSt(..), MData(..) )

newtype STStack s e = STStack {
  valStack :: STRef s [e]
}

-- | The Mutable Stack class
class (MData s m) => MStack s m | s -> m where
  push :: s e -> e -> m ()
  top :: s e -> m (Maybe e)
  pop :: s e -> m (Maybe e)

instance MData (STStack s) (ST s) where
  new :: ST s (STStack s e)
  new = STStack <$> newSTRef []
  len :: Num n => STStack s e -> ST s n
  len stk = fromIntegral . length <$> readSTRef (valStack stk)
  isEmpty :: STStack s e -> ST s Bool
  isEmpty stk = null <$> readSTRef (valStack stk)

instance MStack (STStack s) (ST s) where
  push :: STStack s e -> e -> ST s ()
  push stk val = modifySTRef (valStack stk) (val:)
  top :: STStack s e -> ST s (Maybe e)
  top stk = listToMaybe <$> readSTRef (valStack stk)
  pop :: STStack s e -> ST s (Maybe e)
  pop stk = readSTRef (valStack stk) >>= \case
    [] -> return Nothing
    hd:lst -> do writeSTRef (valStack stk) lst; return $ Just hd

type IOStack = IODataSt

instance (MStack (st RealWorld) (ST RealWorld)) => MStack (IOStack st) IO where
  push (IODataSt st) e = stToIO $ push st e
  top (IODataSt st) = stToIO $ top st
  pop (IODataSt st) = stToIO $ pop st

type IODefStack = IOStack STStack
