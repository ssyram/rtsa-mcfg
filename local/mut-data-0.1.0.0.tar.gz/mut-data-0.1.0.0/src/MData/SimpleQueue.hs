{-# LANGUAGE InstanceSigs #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE MultiParamTypeClasses #-}
module MData.SimpleQueue (
  Queue,
  MData(..),
  MQueue(..),
  IOSimpleQueue
) where

import Control.Monad.ST ( ST )
import Data.STRef
    ( modifySTRef, newSTRef, readSTRef, writeSTRef, STRef )
import Data.Maybe ( listToMaybe )
import MData.MQueue ( MQueue(..), IOQueue )
import MData.Class (MData(..))

type IOSimpleQueue = IOQueue Queue

newtype Queue s e = Queue {
  valQueue :: STRef s [e]
}

instance MData (Queue s) (ST s) where
  new :: ST s (Queue s e)
  new = Queue <$> newSTRef []
  len :: Num n => Queue s e -> ST s n
  len q = fromIntegral . length <$> readSTRef (valQueue q)
  isEmpty :: Queue s e -> ST s Bool
  isEmpty q = null <$> readSTRef (valQueue q)

instance MQueue (Queue s) (ST s) where
  front :: Queue s e -> ST s (Maybe e)
  front q = listToMaybe <$> readSTRef (valQueue q)
  enqueue :: Queue s e -> e -> ST s ()
  enqueue q val = modifySTRef (valQueue q) (++ [val])
  dequeue :: Queue s e -> ST s (Maybe e)
  dequeue q = readSTRef (valQueue q) >>= \case
    []   -> return Nothing
    x:tl -> do writeSTRef (valQueue q) tl; return $ return x
