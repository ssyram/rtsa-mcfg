# mut-data

Mutable data structures for monads ST and IO.
